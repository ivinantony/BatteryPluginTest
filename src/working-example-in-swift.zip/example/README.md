A Capacitor app demonstrating the background geolocation plugin.

    npm i && npx cap sync
    npx cap open android
    npx cap open ios
