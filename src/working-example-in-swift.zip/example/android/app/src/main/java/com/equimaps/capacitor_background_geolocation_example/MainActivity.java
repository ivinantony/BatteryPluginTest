package com.equimaps.capacitor_background_geolocation_example;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
